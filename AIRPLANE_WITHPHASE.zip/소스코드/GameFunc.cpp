#include "GameFunc.h"
int g_current_game_phase = 0;

void InitGame() {
	g_flag_running = true;
}

void ClearGame() {
}
